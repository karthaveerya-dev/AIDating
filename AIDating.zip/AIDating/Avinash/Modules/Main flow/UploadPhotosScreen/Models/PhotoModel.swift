//
//  PhotoModel.swift
//  AIDating
//
//  Created by Mihail Konoplitskyi on 16.02.2021.
//

import Foundation
import UIKit

struct PhotoModel {
    var image: UIImage?
}
