//
//  Notification+name.swift
//  AIDating
//
//  Created by Mihail Konoplitskyi on 15.02.2021.
//

import Foundation

extension Notification.Name {
    static let didTapLookingForLabel = Notification.Name("didTapLookingForLabel")
}
